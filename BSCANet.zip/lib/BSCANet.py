import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from PIL import Image
from .Res2Net_v1b import res2net50_v1b_26w_4s

class BasicConv2d(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1):
        super(BasicConv2d, self).__init__()
        self.conv = nn.Conv2d(in_planes, out_planes,
                              kernel_size=kernel_size, stride=stride,
                              padding=padding, dilation=dilation, bias=False)
        self.bn = nn.BatchNorm2d(out_planes)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        return x

class ChannelAttention(nn.Module):
    def __init__(self, in_planes, rotio=16):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)

        self.sharedMLP = nn.Sequential(
            nn.Conv2d(in_planes, in_planes // rotio, 1),
            nn.ReLU(),
            nn.Conv2d(in_planes // rotio, in_planes, 1, bias=False)
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avgout = self.sharedMLP(self.avg_pool(x))
        maxout = self.sharedMLP(self.max_pool(x))
        return avgout + maxout


class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()
        assert kernel_size in (3, 7), "kernel size must be 3 or 7"
        padding = 3 if kernel_size == 7 else 1

        self.conv = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avgout = torch.mean(x, dim=1, keepdim=True)
        maxout, _ = torch.max(x, dim=1, keepdim=True)
        x = torch.cat([avgout, maxout], dim=1)
        x = self.conv(x)
        return x


class SSEU(nn.Module):
    def __init__(self, channal, s_size=4):
        super(SSEU, self).__init__()
        self.s_size = s_size
        self.channal = channal
        self.catten = ChannelAttention(channal // s_size)
        self.satten = SpatialAttention()
        self.conv1 = BasicConv2d(channal // s_size, channal, kernel_size=1)
        self.conv1_1 = BasicConv2d(channal, channal, kernel_size=3, padding=1)

    def forward(self, x):
        splits = torch.split(x, self.channal // self.s_size, dim=1)
        splited = sum(splits)
        atten = self.satten(splited) + self.catten(splited)
        atten = F.sigmoid(atten)
        atten = F.relu(self.conv1(atten))
        attens = torch.split(atten, self.channal // self.s_size, dim=1)
        a,b,c,d = (att * spl for (att, spl) in zip(attens, splits))
        out = torch.cat((a,b,c,d), dim=1)
        return out + x


class SSEU_e_block(nn.Module):
    def __init__(self, in_planes, out_planes, ks):
        super(SSEU_e_block, self).__init__()
        self.pd = ks // 2
        self.ks = ks
        self.conv0 = BasicConv2d(in_planes, out_planes, kernel_size=1)
        self.conv1xX = BasicConv2d(out_planes, out_planes, kernel_size=(1, ks), padding=(0, self.pd))
        self.convXx1 = BasicConv2d(out_planes, out_planes, kernel_size=(ks, 1), padding=(self.pd, 0))
        self.conv3x3 = BasicConv2d(out_planes, out_planes, kernel_size=3, padding=ks, dilation=ks)
        self.sseu = SSEU(out_planes)

    def forward(self, x):
        x = self.conv0(x)
        x = self.conv1xX(x)
        x = self.convXx1(x)
        x = self.sseu(x)
        x = self.conv3x3(x)
        x = F.relu(x)
        return x


class SSEU_e(nn.Module):
    def __init__(self, in_planes, out_planes):
        super(SSEU_e, self).__init__()
        self.in_planes = in_planes
        self.out_planes = out_planes
        self.e_block2 = SSEU_e_block(in_planes, out_planes, 3)
        self.e_block3 = SSEU_e_block(in_planes, out_planes, 5)
        self.e_block4 = SSEU_e_block(in_planes, out_planes, 7)
        self.conv5_1 = BasicConv2d(3 * out_planes, 1 * out_planes, kernel_size=1)
        self.conv5_2 = BasicConv2d(out_planes, out_planes, kernel_size=3, padding=1)
        self.res = BasicConv2d(in_planes, out_planes, 1)

    def forward(self, x):
        x2 = F.relu(self.e_block2(x))
        x3 = F.relu(self.e_block3(x))
        x4 = F.relu(self.e_block4(x))
        x0 = torch.cat((x2, x3, x4), 1)
        x0 = self.conv5_1(x0)
        x0 = self.conv5_2(x0)
        x0 = F.relu(x0 + self.res(x))
        return x0


class SSEU_d(nn.Module):
    def __init__(self, channel):
        super(SSEU_d, self).__init__()
        self.conv1 = BasicConv2d(channel * 3, channel, 1)
        self.conv2 = BasicConv2d(channel, channel, 3, padding=1)
        self.conv3 = BasicConv2d(channel, channel, 3, padding=1)
        self.conv4 = BasicConv2d(channel, channel, 3, padding=1)
        self.conv5 = nn.Conv2d(channel, out_channels=1, kernel_size=3, padding=1)
        self.sseu = SSEU(channel)
        self.upsample = lambda img, size: F.interpolate(img, size=size, mode='bilinear', align_corners=True)

    def forward(self, f1, f2, f3):
        f1 = self.upsample(f1, f3.shape[-2:])
        f2 = self.upsample(f2, f3.shape[-2:])
        f4 = torch.cat([f1, f1 * f2, f1 * f2 * f3], dim=1)
        f4 = self.conv1(f4)
        f4 = self.sseu(f4)
        out = self.conv5(f4)
        return out, f1, f2, f3, f4


class ATT(nn.Module):
    def __init__(self, channal):
        super(ATT, self).__init__()
        self.conv0 = BasicConv2d(2 * channal, channal, kernel_size=1)
        self.conv1 = BasicConv2d(4 * channal, channal, kernel_size=1)
        self.channal = channal
        self.conv2 = BasicConv2d(channal, channal, kernel_size=3, padding=1)
        self.conv3 = BasicConv2d(channal, channal, kernel_size=3, padding=1)
        self.conv4 = BasicConv2d(channal, 1, kernel_size=1)

    def forward(self, x, feature):
        map = (x-x.min()) / (x.max()-x.min()+1e-8)
        x1 = (map / 0.5).trunc()
        map = map % 0.5
        x2 = (map / 0.25).trunc()
        map = map % 0.25
        x3 = (map / 0.125).trunc()
        map = map % 0.125
        x4 = (map / 0.0625).trunc()
        feature = self.conv0(feature)
        f1 = x1.expand(-1, self.channal, -1, -1) * feature
        f2 = x2.expand(-1, self.channal, -1, -1) * feature
        f3 = x3.expand(-1, self.channal, -1, -1) * feature
        f4 = x4.expand(-1, self.channal, -1, -1) * feature
        f = torch.cat((f1, f2, f3, f4), dim=1)
        f = F.relu(self.conv1(f))
        f = F.relu(self.conv2(f))
        out = self.conv4(f)
        out = out + x
        return out, f


class BSCANet(nn.Module):
    # res2net based encoder decoder
    def __init__(self, channel=64):
        super(BSCANet, self).__init__()
        # ---- ResNet Backbone ----
        self.resnet = res2net50_v1b_26w_4s(pretrained=True)
        # ---- SSEU_E ----
        self.encode2_1 = SSEU_e(512, channel)
        self.encode3_1 = SSEU_e(1024, channel)
        self.encode4_1 = SSEU_e(2048, channel)
        # ---- SSEU_D ----
        self.sseu_d = SSEU_d(channel)
        # ----- att
        self.att4 = ATT(channel)
        self.att3 = ATT(channel)
        self.att2 = ATT(channel)

    def forward(self, x):
        x = self.resnet.conv1(x)
        x = self.resnet.bn1(x)
        x = self.resnet.relu(x)
        x = self.resnet.maxpool(x)  # bs, 64, 88, 88
        # ---- low-level features ----
        x1 = self.resnet.layer1(x)  # bs, 256, 88, 88
        x2 = self.resnet.layer2(x1)  # bs, 512, 44, 44
        x3 = self.resnet.layer3(x2)  # bs, 1024, 22, 22
        x4 = self.resnet.layer4(x3)  # bs, 2048, 11, 11

        x2_encode = self.encode2_1(x2)  # bs, 64, 44, 44
        x3_encode = self.encode3_1(x3)  # bs, 64, 22, 22
        x4_encode = self.encode4_1(x4)  # bs, 64, 11, 11

        crop_5, x4, x3, x2, f5 = self.sseu_d(x4_encode, x3_encode, x2_encode)  # bs 64 44 44

        lateral_map_5 = F.interpolate(crop_5, scale_factor=8,
                                      mode='bilinear')  # NOTES: Sup-1 (bs, 1, 44, 44) -> (bs, 1, 352, 352)

        crop_4, f4 = self.att4(crop_5, torch.cat((x4, f5), dim=1))
        lateral_map_4 = F.interpolate(crop_4, scale_factor=8,
                                      mode='bilinear')  # NOTES: Sup-2 (bs, 1, 44, 44) -> (bs, 1, 352, 352)

        crop_3, f3 = self.att3(crop_4, torch.cat((x3, f4), dim=1))
        lateral_map_3 = F.interpolate(crop_3, scale_factor=8,
                                      mode='bilinear')  # NOTES: Sup-3 (bs, 1, 44, 44) -> (bs, 1, 352, 352)

        crop_2, f2 = self.att2(crop_3, torch.cat((x2, f3), dim=1))
        lateral_map_2 = F.interpolate(crop_2, scale_factor=8,
                                      mode='bilinear')  # NOTES: Sup-4 (bs, 1, 44, 44) -> (bs, 1, 352, 352)

        return lateral_map_5, lateral_map_4, lateral_map_3, lateral_map_2


if __name__ == '__main__':
    ras = BSCANet().cuda()
    input_tensor = torch.randn(1, 3, 352, 352).cuda()

    out = ras(input_tensor)